const SubCard = ({ headingOne, content }) => {
    return (
        <>
            <div className="conatiner">

                <div className="row">

                        <div className="card">

                            <div className="card-content">

                                <div className="card-body">

                                    <div className ="media d-flex">
                                       
                                        <div className="media-body text-right">

                                            <h4>{headingOne}</h4>

                                            <span>{content}</span>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

        </>
    )
};

export default SubCard;