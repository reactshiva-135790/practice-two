import "./chartMarket.css"
import { NavLink, Outlet } from "react-router-dom";
import SubCard from "../subCard/SubCard";

const ChartMarket = () => {
    return (
        <>

            <header id="header">

                <div className="container-fluid ">

                    <div className="row">

                        <div class="mt-3 mr-2 col-xl-3 col-sm-6 col-12">

                            <SubCard headingOne="24h High" content="311.5" />

                        </div>

                        <div className="mt-3 mr-2 col-xl-3 col-sm-6 col-12">

                            <SubCard headingOne="24h Low" content="298.7" />

                        </div>

                        <div className="mt-3 mr-2 col-xl-3 col-sm-6 col-12 ">

                            <SubCard headingOne="24h Volume(TRD)" content="339,041.17" />

                        </div>

                        <div className="mt-3 mr-2 col-xl-3 col-sm-6 col-12">

                            <SubCard headingOne="24h Volume(FUSD)" content="339,04" />

                        </div>


                    </div>

                </div>


            </header>


            <nav className="position-sticky navbar navbar-light bg-light mb-5">

                <form className="container-fluid d-flex gap-5 justify-content-center">

                    <button className="btn btn-light" type="button"><NavLink to="chartMarket-chart">Chart</NavLink></button>

                    <button className="btn btn-light" type="button"><NavLink to="chartMarket-order-book">Order Book</NavLink></button>

                    <button className="btn btn-light" type="button"><NavLink to="chartMarket-trades">Trades</NavLink></button>

                </form>

            </nav>

            <Outlet />

            <ul className="d-flex gap-3 justify-content-center mt-5 list-style">
                <li>Open Orders(0)</li>
                <li>Order History</li>
                <li>Trade History</li>
                <li>Funds</li>
                <li>Positions(0)</li>
            </ul>


            <div className="box-market">

                <h6><span className="color-span">Log In</span> or <span className="color-span">Register Now</span> to trade</h6>
           
            </div>

            {/*<div className="chart-market-footer">
                <ul className="d-flex list-style-footer">
                    <li>stable Connection</li>
                    <li>Announcements</li>
                </ul>
    </div>*/}

        </>
    )
}

export default ChartMarket;