export const Chart = () => (
	<>

		<div className="container">

			<div className="row">

				chart.chart

			</div>

		</div>

	</>
);

export default Chart;