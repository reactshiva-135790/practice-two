import searchPage from "../../assets/images/searchPage.png"

const Reusable = () => {
    return (
        <>
            <img src={searchPage} className="style-image" />

            <h6 className="spot-text">No results. Go to spot market to add your favorite tokens.</h6>

        </>
    )

};

export default Reusable;