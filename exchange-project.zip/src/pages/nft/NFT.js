import "./nft.css";

const NFT = () => {
    return (
        <>
            <h1>NFT</h1>
        </>
    )

}
export default NFT;