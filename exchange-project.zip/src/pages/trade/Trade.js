import "./trade.css"

const Trade = () => {
    return (
        <div>
            <h1>Trade</h1>
        </div>
    )
};

export default Trade;