const Derivatives = () => {
    return (
        <div className="container">
            <div className="row">
                Derivatives
            </div>
        </div>
    )
}

export default Derivatives;