import "./earn.css";

const Earn = () => {
    return (
        <div>
            <h1>Earn</h1>
        </div>
    )
};

export default Earn;